<?php

$_SESSION['basket'] = [];

?>