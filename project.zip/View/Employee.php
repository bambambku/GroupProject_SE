<?php 
session_start();
if ($_SESSION["user_role"]!=2){
  header("Location: ../View/logout.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/style-desktop.css" media="screen and (min-width: 1025px)">
    <title>Employee</title>
</head>
<body id="background2">
        <div class="decoration-bar"></div>
        <div class="sidebar">
            <div class="menu-picture-container">
                <img src="../Pictures/logo.png" alt="logo" class="menu-picture">
                <div class="underlogo">
                    <h2 class="name-txt"><?php echo $_SESSION['user_firstName'] . " " . $_SESSION['user_surname']?></h2>
                    <p class="job-title-txt">Employee</p>
                </div>
                <ul class="menu">
                    <li><a href="">New Sale</a></li>
                    <li><a href="">Stock</a></li>
                    <li class="bttn-logout"><a href="logout.php">Logout</a></li>
                </ul>
             </div>
        </div>   
    <footer>
    <div class="footer-content">
        <p>&copy; 2024 Terra Core. All rights reserved.</p>
        <nav>
            <ul>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="">Privacy Policy</a></li>
            </ul>
        </nav>
    </div>
    </footer>
</body>
</html>